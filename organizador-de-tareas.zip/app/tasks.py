# --- app/Tasks ---

from flask import Blueprint, render_template, request, redirect, url_for, g
from .models import Task
from app import db
from app.auth import login_required

bp = Blueprint('tasks', __name__, url_prefix='/tasks')


@bp.route('/list')
@login_required
def index():
    task_count = int(request.args.get('task_count', 5))
    sort_by = request.args.get('sort_by', 'asc')
    tasks = Task.query.filter_by(user=g.user.id).order_by(
        Task.prioridad.asc() if sort_by == 'asc' else Task.prioridad.desc()
    ).limit(task_count).all()

    return render_template('tasks/index.html', tasks=tasks, task_count=task_count, sort_by=sort_by)


@bp.route('/create', methods=('GET', 'POST'))
@login_required
def create():
    if request.method == 'POST':
        prioridad = request.form['prioridad']
        title = request.form['title']
        desc = request.form['desc']
        

        task = Task(g.user.id,  prioridad, title, desc)
        db.session.add(task)
        db.session.commit()
        return redirect(url_for('tasks.index'))

    return render_template('tasks/create.html')


def get_task(id):
    task = Task.query.get_or_404(id)
    return task

@bp.route('/update/<int:id>', methods=('GET', 'POST'))
@login_required
def update(id):
    task = get_task(id)
    if request.method == 'POST':
        task.title = request.form['title']
        task.desc = request.form['desc']
        task.prioridad = request.form['prioridad']
        task.state = 'state' in request.form  # Cambiado para manejar el checkbox correctamente

        db.session.commit()
        return redirect(url_for('tasks.index'))

    return render_template('tasks/update.html', task=task)


@bp.route('/delete/<int:id>')
@login_required
def delete(id):
    task = get_task(id)
    db.session.delete(task)
    db.session.commit()
    return redirect(url_for('tasks.index'))
