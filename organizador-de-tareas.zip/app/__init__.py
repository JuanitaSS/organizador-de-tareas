#app/__init__.py
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)

    # Configuración del proyecto
    app.config.from_mapping(
        DEBUG=True,
        SECRET_KEY='dev',
        SQLALCHEMY_DATABASE_URI="sqlite:///tareas.db"
    )

    db.init_app(app)

    # Registrar Blueprint
    from . import tasks
    app.register_blueprint(tasks.bp)

    from . import auth
    app.register_blueprint(auth.bp)

    @app.route('/')
    def index():
        #return 'Hola flask!'
        return render_template('index.html')

    with app.app_context():
        db.create_all()

    app.run(host='0.0.0.0', port=81)

    return app